package com.expense.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.expense.models.Department;
import com.expense.models.Status;
import com.expense.services.DepartmentService;

@RestController
@RequestMapping("/department")
public class DepartmentController {
	
	@Autowired
	DepartmentService departmentService;
	
	@RequestMapping(value = "/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Department> getAllDepartment(){
		return departmentService.getAllDepartment();
	}
	
	@RequestMapping(value = "/getbyid/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Department> getDepartmentById(@PathVariable(value = "id") long departId) {
		Optional<Department> optional = departmentService.getDepartmentById(departId);
		Department department = optional.get();
		return ResponseEntity.ok().body(department);
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public Department createDepartment(@RequestBody Department department) {
		return departmentService.createDepartment(department);
	}
	
	@RequestMapping(value = "/update/{id}", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Department> updateDepartment(@PathVariable(value = "id") long departId,@RequestBody Department department) {
		Optional<Department> optional = departmentService.getDepartmentById(departId);
		Department depart = optional.get();
		
		depart.setDepartmentId(department.getDepartmentId());
		depart.setName(department.getName());
		
		final Department updateDepartment = departmentService.createDepartment(depart);		
		return ResponseEntity.ok(updateDepartment);	
	}
	
	@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, Boolean> deleteDepartment(@PathVariable(value = "id") long departmentId) {
		
		Optional<Department> optional = departmentService.getDepartmentById(departmentId);
		Department department = optional.get();
		
		if(departmentId==department.getDepartmentId()) {
			Object object=departmentService.deleteDepartment(department);
			Map<String, Boolean> response = new HashMap<>();
			response.put("deleted", Boolean.TRUE);
			return response;
			
		} else {
			return null;		
		}
		
	
	}
	
	
}
