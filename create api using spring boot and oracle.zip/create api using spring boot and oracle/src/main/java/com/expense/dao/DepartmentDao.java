package com.expense.dao;

import java.util.List;
import java.util.Optional;

import com.expense.models.Department;

public interface DepartmentDao {

	List<Department> getAllDepartment();

	Optional<Department> getDepartmentById(long departId);

	Department createDepartment(Department department);

	Object deleteDepartment(Department department);

	
}
