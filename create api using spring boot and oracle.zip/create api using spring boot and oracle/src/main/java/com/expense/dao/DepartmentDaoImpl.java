package com.expense.dao;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.expense.models.Department;
import com.expense.repositories.DepartmentRepository;

@Repository
public class DepartmentDaoImpl implements DepartmentDao {

	@Autowired
	DepartmentRepository departmentRepository; 

	@Override
	public List<Department> getAllDepartment() {
		return departmentRepository.findAll();
	}

	@Override
	public Optional<Department> getDepartmentById(long departId) {
		return  departmentRepository.findById(departId);
	}

	@Override
	public Department createDepartment(Department department) {
		return departmentRepository.save(department);
	}

	@Override
	public Object deleteDepartment(Department department) {
		departmentRepository.delete(department);
		return department;
	}

	

}
