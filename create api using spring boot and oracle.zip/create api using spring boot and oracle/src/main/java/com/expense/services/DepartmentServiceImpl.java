package com.expense.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.expense.dao.DepartmentDao;
import com.expense.models.Department;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	DepartmentDao departmentDao;
	
	@Override
	public List<Department> getAllDepartment() {
		return departmentDao.getAllDepartment();
	}

	@Override
	public Optional<Department> getDepartmentById(long departId) {
		return departmentDao.getDepartmentById(departId);
	}

	@Override
	public Department createDepartment(Department department) {
		return departmentDao.createDepartment(department);
	}

	@Override
	public Object deleteDepartment(Department department) {
		return departmentDao.deleteDepartment(department);
	}

	

}
