package com.expense.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "M_DEPARTMENT")
public class Department {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "M_DEPARTMENT_S")
	@SequenceGenerator(name = "M_DEPARTMENT_S", sequenceName = "M_DEPARTMENT_SEQUENCE", allocationSize = 1)
	@Column(name = "M_DEPARTMENT_ID", updatable = false, nullable = false)
	private long departmentId;
	
	@Column(name = "NAME")
	private String name;

	public Department() {
		// TODO Auto-generated constructor stub
	}

	public Department(long departmentId, String name) {
		this.departmentId = departmentId;
		this.name = name;
	}

	public long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(long departmentId) {
		this.departmentId = departmentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
}
